package com.layer.xdk.ui.style;

import android.content.Context;
import android.util.AttributeSet;

public abstract class ItemStyle {

    public ItemStyle() {}
    /**
     * Empty marker class to ensure type safety
     */

    public ItemStyle(Context context, AttributeSet attrs, int defStyle) {

    }
}
