package com.layer.xdk.ui.message.adapter;


public enum MessageGrouping {
    OLDEST_MESSAGE,
    GROUP_START,
    SUB_GROUP_END,
    SUB_GROUP_MIDDLE,
    SUB_GROUP_START,
    NEWEST_MESSAGE
}
