package com.layer.xdk.ui.typingindicator;

public enum TypingIndicatorMode {
    INLINE,
    TEXT,
    BOTH
}
