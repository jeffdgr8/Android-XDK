package com.layer.xdk.ui.message.view;

import android.graphics.drawable.Drawable;

public interface IconProvider {
    Drawable getIconDrawable();
}
